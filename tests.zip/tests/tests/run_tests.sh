#!/bin/sh

# test for proper number of script arguments
if [ $# -lt 1 ]
then
  echo "usage:  run_tests.sh <dir_with_lisp_executable>"
  exit 1
fi
lisp_bin_dir=$1


thin_divider="........................................" 
thick_divider="========================================" 


\ls *.lsp |
while read test_file
do
  echo $thick_divider
  echo $test_file
  echo $thick_divider
  cat $test_file
  echo $thin_divider
  $lisp_bin_dir/greglisp.exe 0 < $test_file
  echo
  echo
done
